package hell.entities;

public class CommonItem extends Items {

    public CommonItem(String name, int strength, int agility, int intelligence, int hitPoints, int damage) {
        super (name, strength, agility, intelligence, hitPoints, damage);
    }
}
