package hell.interfaces;

public interface Engine extends Runnable {
}
