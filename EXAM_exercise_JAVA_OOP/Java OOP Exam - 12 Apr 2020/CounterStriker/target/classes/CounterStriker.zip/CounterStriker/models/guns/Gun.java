package CounterStriker.models.guns;

public interface Gun {
    String getName();

    int getBulletsCount();

    int fire();
}
