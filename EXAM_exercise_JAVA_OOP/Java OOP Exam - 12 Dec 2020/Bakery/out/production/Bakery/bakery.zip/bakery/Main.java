package bakery;

import bakery.core.ControllerImpl;
import bakery.core.EngineImpl;
import bakery.core.interfaces.Controller;
import bakery.entities.bakedFoods.interfaces.BakedFood;
import bakery.entities.drinks.interfaces.Drink;
import bakery.entities.tables.interfaces.Table;

import bakery.io.ConsoleReader;
import bakery.io.ConsoleWriter;
import bakery.repositories.DrinkRepositoryImpl;
import bakery.repositories.FoodRepositoryImpl;
import bakery.repositories.TableRepositoryImpl;
import bakery.repositories.interfaces.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner (System.in);
        BufferedReader bufferedReader = new BufferedReader (new InputStreamReader (System.in));

        String a = " ";
        int a1 = a.length();
        FoodRepository<BakedFood> foodRepository = new FoodRepositoryImpl (); // TODO:  new FoodRepositoryImpl<>();
        DrinkRepository<Drink> drinkRepository = new DrinkRepositoryImpl ();  // TODO:  new DrinkRepositoryImpl<>();
        TableRepository<Table> tableRepository = new TableRepositoryImpl (); // TODO:  new TableRepositoryImpl<>();

        Controller controller = new ControllerImpl (foodRepository, drinkRepository, tableRepository); // TODO: new ControllerImpl(foodRepository, drinkRepository, tableRepository);
          //  String[] input = bufferedReader.readLine ().split (" ");
          //  if(input[0].equals ("AddFood")){
             //   System.out.println (controller.addFood (input[1],input[2], Double.parseDouble (input[3])));
          //  }else if(input[0].equals ("AddDrink")){
               // System.out.println (controller.addDrink (input[1], input[2], Integer.parseInt (input[3]),input[4]));
           // }else if(input[0].equals ("AddTable")){
              //  System.out.println (controller.addTable (input[1], Integer.parseInt (input[2]),Integer.parseInt (input[3])));
          //  }else if(input[0].equals ("ReserveTable")){
            //    System.out.println (controller.reserveTable (Integer.parseInt (input[1])));
          //  }else if(input[0].equals ("OrderFood")){
          //      System.out.println (controller.orderFood (Integer.parseInt (input[1]), input[2]));
          //  }else if(input[0].equals ("OrderDrink")){
           //     System.out.println (controller.orderDrink (Integer.parseInt (input[1]), input[2], input[3]));
           // }else if(input[0].equals ("LeaveTable")){
              //  System.out.println (controller.leaveTable (Integer.parseInt (input[1])));
          //  }else if(input[0].equals ("GetFreeTablesInfo")){
              //  System.out.println (controller.getFreeTablesInfo ());
           // }else if(input[0].equals ("GetTotalIncome")){
              //  System.out.println (controller.getTotalIncome ());
          //  }else if(input[0].equals ("END")){

          //  }
        // TODO:OPTIONAL
       ConsoleReader reader = new ConsoleReader();
       ConsoleWriter writer = new ConsoleWriter();
        EngineImpl engine = new EngineImpl (reader, writer, controller);
       engine.run();
    }
}
