package viceCity.models.neighbourhood;

import viceCity.models.guns.Gun;
import viceCity.models.players.MainPlayer;
import viceCity.models.players.Player;

import java.util.ArrayList;
import java.util.Collection;
import java.util.stream.Collectors;

public class GangNeighbourhood implements Neighbourhood{

    @Override
    public void action(Player mainPlayer, Collection<Player> civilPlayers) {
        while (true){
            if(mainPlayer.isAlive ()){
                break;
            }
            while (!mainPlayer.getGunRepository ().getModels ().isEmpty () && !civilPlayers.isEmpty ()){
                for (Gun out: mainPlayer.getGunRepository ().getModels ()) {
                    if(out.canFire ()){
                    for (Player outPlayer: civilPlayers) {
                        while (outPlayer.isAlive ()){
                        if(out.canFire ()){
                            outPlayer.takeLifePoints (out.fire ());
                           }
                        }

                       }civilPlayers = civilPlayers.stream ().filter (f -> f.isAlive ()).collect(Collectors.toList());
                    }else {
                        mainPlayer.getGunRepository ().getModels ().remove (out);
                    }
                }
            }if(!civilPlayers.isEmpty ()){
                for(Player out: civilPlayers){
                    for(Gun outGun : out.getGunRepository ().getModels ()){
                        mainPlayer.takeLifePoints (outGun.fire ());
                        if(!mainPlayer.isAlive ()){
                            break;
                        }
                    }
                }
            }
        }
    }
}
